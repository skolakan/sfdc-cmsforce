



function getParam(name)
{
  var regexS = "[\\?&]"+name+"=([^&#]*)";
  var regex = new RegExp( regexS );
  var targetURL = window.location.href;
  var results = regex.exec( targetURL );
  if( results == null )
    return "";
  else
    return results[1];
}
function getDriver(currentHref)
{
	var key = "d";
	if (top.location.href.indexOf('?') > -1)
	{
		if (currentHref.indexOf('?') > -1)
		{
			var newQuery = "";
				
			var targetJSP = currentHref.substr(0, currentHref.indexOf('?'));
			var query = currentHref.substr(currentHref.indexOf('?'));
			var keyValuePairs = query.split("&");
					
			var queryParams = currentHref.substr(currentHref.indexOf('?') + 1);				
			var ParamPairs = queryParams.split("&");
					
			var value = getParam(key);
		
			for (var k = 0; k < keyValuePairs.length; k++)
			{
				if (ParamPairs[k].split("=")[0] == key)
				{
					var thePair = keyValuePairs[k].split("=");		
					keyValuePairs[k] = thePair[0] + "=" + value;
				}
				
				if (k != 0)
				{
					newQuery += "&";
				}		
				newQuery += keyValuePairs[k];
			}
			return targetJSP + newQuery;
		}
		else
		{
			var finalHREF = currentHref + top.location.href.substr(window.location.href.indexOf('?'))
			return finalHREF;
		}
	}
	else
	{
		return currentHref;
	}
}


function getURLParam(strParamName){
  var strReturn = "";
  var strHref = window.location.href;
  if ( strHref.indexOf("&") > -1 ){
    var strQueryString = strHref.substr(strHref.indexOf("&")).toLowerCase();
    var aQueryString = strQueryString.split("&");
    for ( var iParam = 0; iParam < aQueryString.length; iParam++ ){
      if (
aQueryString[iParam].indexOf(strParamName + "=") > -1 ){
        var aParam = aQueryString[iParam].split("=");
        strReturn = aParam[1];
        break;
      }
    }
  }
  return strReturn;
}

function isValidPhoneNumber(num, requiredDigits) {
    var digits = 0;
    if (num == null) return false;
    for( i=0; i<num.length; i++ ){
        var c = num.charCodeAt(i);  
        //convert the i-th character to ascii code value
        if( (c>=48) && (c<=57) ) digits++;
    }    
    return (digits >= requiredDigits);
}

/********
 * Verify that an email addres is valid
 * Written by Paolo Wales (paolo@taize.fr)
********/

function isValidEmail(emailad) {

   var exclude=/[^@\-\.\w\']|^[_@\.\-]|[\._\-]{2}|[@\.]{2}|(@)[^@]*\1/;
   var check=/@[\w\-]+\./;
   var checkend=/\.[a-zA-Z]{2,4}$/;
   if(((emailad.search(exclude) != -1) ||
       (emailad.search(check)) == -1) ||
       (emailad.search(checkend) == -1)){
      return false;
   } else {
      return true;
   }
}

/********
 * Ensures valid emails are present and that the sender email doesn't contain
 * an 'salesforce.com' in the sender's domain.
 * 
 * use: for "email a friend" security
 * created by: Scott Yancey
********/

function isValidEmails() {
   
   var recipientEmail = document.forms[0].recipientEmail.value;
   var senderEmail = document.forms[0].senderEmail.value;
   var error = false;
   
   var errorMessage = "The following errors are present:\n\n";
   
   if (recipientEmail.indexOf(',') < 0) {
   		if (!isValidEmail(recipientEmail)){
   			error = true;
			errorMessage += "The recipient's Email address is not valid\n"
   	  }	
   } else {
   
   	 var addresses = new Array();
	 addresses = recipientEmail.split(',');
	 var currentAddress;
	 var i;
	 for (var i=0; i < addresses.length; i++) {      
	
		if (!isValidEmail(trim(addresses[i]))){
   			error = true;
   	    }
		
	 }
	 if (i > 10) {
			error = true;
			errorMessage += "Only 10 addresses are allowed\n"	
	 } 
	 if (error) {
	 	errorMessage += "A recipient's Email address is not valid\n"	
	 } 
	 
   }

   if (!isValidEmail(senderEmail)) {
   	error = true;
	errorMessage += "The sender's Email address is not valid"
   }
   if (senderEmail.indexOf("salesforce.com") >= 0) {
   	error = true;
	errorMessage += "The sender's Email address can not contain 'salesforce.com'."
   }
   
   if (error) {
      alert(errorMessage);
      return false;
   } else {
      return true;
   }
}

//added by K Guckian moved over from existing site js this is for the interactive screenshot

function launchDemo(url){
	var winwidth=screen.width;
	var winheight=screen.height;
	var scroll="";

	if(winwidth>1000){
		winwidth=1020;
		winheight=700;
		scroll="no";
	}else if(winwidth<1000){
		winwidth=790;
		winheight=530;
		scroll="yes";
	}
	url=url+"&scroll="+scroll;
	newWindow=window.open(url,"Demo","toolbar=no,scrollbars=no,resizable=no,width="+winwidth+",height="+winheight+",left=0,top=0");
}

function referFriend(url){
        var referurl=document.location.href;
        url=url+"?referurl=" + referurl+"&title="+document.title;
	newWindow=window.open(url,"","toolbar=no,scrollbars=no,resizable=no,width=350,height=500,left=0,top=0");
}

/**
*
*  URL encode / decode
*  http://www.webtoolkit.info/
*
**/

var Url = {

    // public method for url encoding
    encode : function (string) {
        return escape(this._utf8_encode(string));
    },

    // public method for url decoding
    decode : function (string) {
        return this._utf8_decode(unescape(string));
    },

    // private method for UTF-8 encoding
    _utf8_encode : function (string) {
        string = string.replace(/\r\n/g,"\n");
        var utftext = "";

        for (var n = 0; n < string.length; n++) {

            var c = string.charCodeAt(n);

            if (c < 128) {
                utftext += String.fromCharCode(c);
            }
            else if((c > 127) && (c < 2048)) {
                utftext += String.fromCharCode((c >> 6) | 192);
                utftext += String.fromCharCode((c & 63) | 128);
            }
            else {
                utftext += String.fromCharCode((c >> 12) | 224);
                utftext += String.fromCharCode(((c >> 6) & 63) | 128);
                utftext += String.fromCharCode((c & 63) | 128);
            }

        }

        return utftext;
    },

    // private method for UTF-8 decoding
    _utf8_decode : function (utftext) {
        var string = "";
        var i = 0;
        var c = c1 = c2 = 0;

        while ( i < utftext.length ) {

            c = utftext.charCodeAt(i);

            if (c < 128) {
                string += String.fromCharCode(c);
                i++;
            }
            else if((c > 191) && (c < 224)) {
                c2 = utftext.charCodeAt(i+1);
                string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
                i += 2;
            }
            else {
                c2 = utftext.charCodeAt(i+1);
                c3 = utftext.charCodeAt(i+2);
                string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
                i += 3;
            }

        }

        return string;
    }

}

var keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";

function encode64(input) {
   var output = "";
   var chr1, chr2, chr3;
   var enc1, enc2, enc3, enc4;
   var i = 0;

   do {
      chr1 = input.charCodeAt(i++);
      chr2 = input.charCodeAt(i++);
      chr3 = input.charCodeAt(i++);

      enc1 = chr1 >> 2;
      enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
      enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
      enc4 = chr3 & 63;

      if (isNaN(chr2)) {
         enc3 = enc4 = 64;
      } else if (isNaN(chr3)) {
         enc4 = 64;
      }

      output = output + keyStr.charAt(enc1) + keyStr.charAt(enc2) + 
         keyStr.charAt(enc3) + keyStr.charAt(enc4);
   } while (i < input.length);
   
   return output;
}

function decode64(input) {
   var output = "";
   var chr1, chr2, chr3;
   var enc1, enc2, enc3, enc4;
   var i = 0;

   // remove all characters that are not A-Z, a-z, 0-9, +, /, or =
   input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");

   do {
      enc1 = keyStr.indexOf(input.charAt(i++));
      enc2 = keyStr.indexOf(input.charAt(i++));
      enc3 = keyStr.indexOf(input.charAt(i++));
      enc4 = keyStr.indexOf(input.charAt(i++));

      chr1 = (enc1 << 2) | (enc2 >> 4);
      chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
      chr3 = ((enc3 & 3) << 6) | enc4;

      output = output + String.fromCharCode(chr1);

      if (enc3 != 64) {
         output = output + String.fromCharCode(chr2);
      }
      if (enc4 != 64) {
         output = output + String.fromCharCode(chr3);
      }
   } while (i < input.length);

   return output;
}

function getArgs(arg_name, str) {
 var value = "", tmpstr = "";
 if (!str) str = location.search.substring(1);
 if (!str) return value;
 else {
  var tmparray = str.split("&");
  for (i=0; i<tmparray.length; i++) {
   tmpstr = tmparray[i];
   if (tmpstr.indexOf(arg_name + "=") != -1) {
    var tmp2array = tmparray[i].split("=");
    value = tmp2array[1];
   }
  }
 }
 return value;
}

function readCookie(name) {
	var nameEQ = name + "=";
	var ca = document.cookie.split(';');
	for(var i=0;i < ca.length;i++) {
		var c = ca[i];
		while (c.charAt(0)==' ') c = c.substring(1,c.length);
		if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
	}
	return null;
}



/********
 * Opens a new window
********/

var curPopupWindow = null;

function openWindow(url, winName, width, height, center, winType) {

   var xposition = 50; // Postions the window vertically in px
   var yposition = 50; // Postions the window horizontally in px
   var location, menubar, resizable, scrollbars, status, titlebar;

   if ((parseInt(navigator.appVersion) >= 4 ) && (center)){
       xposition = (screen.width - 800) / 2;
       yposition = (screen.height - 600) / 2;
   } 
   
   if (winType == "1") {           // winType 1 is for regular popup windows
      location=1;
      menubar=1;
      resizable=1;
      scrollbars=1;
      status=1;
      titlebar=1;
   } else if (winType == "2") {   // winType 2 is for Quick Tour like popups
      location=0;
      menubar=0;
      resizable=0;
      scrollbars=0;
      status=0;
      titlebar=1;
   } else if (winType == "3") {   // winType 3 is for footer like popups
      location=0;
      menubar=0;
      resizable=1;
      scrollbars=1;
      status=0;
      titlebar=1;
   } else if (winType == "4") { // winType 4 sforce footer - no resizing
      location=0;
      menubar=0;
      resizable=0;
      scrollbars=1;
      status=0;
      titlebar=0;
   } else if (winType == "5") {
      location=0;
      menubar=1;
      resizable=0;
      scrollbars=1;
      status=0;
      titlebar=0;
   }else {                       // if no arg is passed for winType
      location=1;
      menubar=1;
      resizable=1;
      scrollbars=1;
      status=1;
      titlebar=1;
   } 
   
   // Features to specify for a new window
   args = "width=" + width + ","
   + "height=" + height + ","
   + "location=" + location + ","
   + "menubar=" + menubar + ","
   + "resizable=" + resizable + ","
   + "scrollbars=" + scrollbars + ","
   + "status=" + status + ","
   + "titlebar=" + titlebar + ","
   + "toolbar=0,"
   + "hotkeys=0,"
   + "screenx=" + xposition + ","  //NN Only
   + "screeny=" + yposition + ","  //NN Only
   + "left=" + xposition + ","     //IE Only
   + "top=" + yposition;           //IE Only
   
	// Performs the opening of the window (and closing of a window already opened for that page).
	if (curPopupWindow != null) {
		curPopupWindow.close();
	}
	curPopupWindow = window.open(url, winName, args, false);
	curPopupWindow.focus();
}

function readCookie(name) {
	var nameEQ = name + "=";
	var ca = document.cookie.split(';');
	for(var i=0;i < ca.length;i++) {
		var c = ca[i];
		while (c.charAt(0)==' ') c = c.substring(1,c.length);
		if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
	}
	return null;
}

var RemoveMe = {

  network : 'salesforce.com',
  stagingDomains : ['internal.salesforce.com','soma.salesforce.com','localhost'],

  isProduction : function() {
    for (i in this.stagingDomains) {
      if (self.location.href.indexOf(this.stagingDomains[i]) > 0) {
        this.network = this.stagingDomains[i];
        break;
      }
    }
     return (this.network=='salesforce.com');
  },

  isStage : function() {
     return !this.isProduction();
  }
}

if (RemoveMe.isStage()) {
  alert('This page contains an obsolete version of our global JS file.\n' +
        'The correct version is global2.js. Please contact the WebDev team and\n' +
        'request that the template for this page be updated.\n\n' + 
        'Please note, this message will NOT be diplayed on the live site!');
}


